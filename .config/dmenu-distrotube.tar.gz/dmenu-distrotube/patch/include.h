#if DYNAMIC_OPTIONS_PATCH
#include "dynamicoptions.h"
#endif
#if JSON_PATCH
#include "json.h"
#endif
#if NON_BLOCKING_STDIN_PATCH
#include "nonblockingstdin.h"
#endif
#if NUMBERS_PATCH
#include "numbers.h"
#endif