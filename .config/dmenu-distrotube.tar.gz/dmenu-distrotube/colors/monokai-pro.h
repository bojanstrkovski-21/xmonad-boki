static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#FCFCFA", "#2D2A2E" },
	[SchemeSel] = { "#000000", "#AB9DF2" },
	[SchemeSelHighlight] = { "#A9DC76", "#000000" },
	[SchemeNormHighlight] = { "#A9Dc76", "#000000" },
	[SchemeOut] = { "#2D2A2E", "#78DCE8" },
	[SchemeMid] = { "#FCFCFA", "#000000" },
};
