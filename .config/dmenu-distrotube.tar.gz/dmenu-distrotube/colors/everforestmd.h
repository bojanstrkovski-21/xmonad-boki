static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#d3c6aa", "#2d353b" },
	[SchemeSel] = { "#d3c6aa", "#33658a" },
	[SchemeSelHighlight] = { "#d699b6", "#33658a"},
	[SchemeNormHighlight] = { "#83c092", "#2d353b" },
	[SchemeOut] = { "#2d353b", "#7fbbb3" },
	[SchemeMid] = { "#d3c6aa", "#2d353b" },
};
